package com.autozone.notification.engine.actvmq;

import javax.jms.Message;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class JMSListener {

	@JmsListener(destination = "enterprise.document.topic")
	public void receiveMessage(final Message payload)
	{
		System.out.println("Received message "+payload);
		
	}
}
